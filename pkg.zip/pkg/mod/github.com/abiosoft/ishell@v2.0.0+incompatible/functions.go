package ishell

import (
	"os"
)

func exitFunc(c *Context) {
	c.Stop()
}

func helpFunc(c *Context) {
	c.Println(c.HelpText())
}

func clearFunc(c *Context) {
	err := c.ClearScreen()
	if err != nil {
		c.Err(err)
	}
}

func addDefaultFuncs(s *Shell) {
	s.AddCmd(&Cmd{
		Name: "exit",
		Help: "帮助工具 | 退出程序",
		Order: -2,
		Func: exitFunc,
	})
	s.AddCmd(&Cmd{
		Name: "help",
		Order: -3,
		Help: "帮助工具 | 查看所有命令",
		Func: helpFunc,
	})
	s.AddCmd(&Cmd{
		Order: -1,
		Name: "clear",
		Help: "帮助工具 | 清屏",
		Func: clearFunc,
	})
	s.Interrupt(interruptFunc)
}

func interruptFunc(c *Context, count int, line string) {
	if count >= 2 {
		c.Println("Interrupted")
		os.Exit(1)
	}
	c.Println("Input Ctrl-c once more to exit")
}
